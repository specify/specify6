//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.apple.eawt;

public class Application {
    public Application() {
    }

    public void setEnabledPreferencesMenu(boolean value) {
    }

    public void addApplicationListener(ApplicationAdapter aa) {
    }

    public void setAboutHandler(AboutHandler h) {
    }

    public void setQuitHandler(QuitHandler h) {
    }

    public void setPreferencesHandler(PreferencesHandler h) {
    }

    public void doAbout(){
    }

    public void doPreferences(){
    }

    public void ddExit(boolean a){
    }

    static public Application getApplication() {
        return new Application();
    }
}
