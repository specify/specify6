//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.apple.eawt;

public class PreferencesHandler {
    public PreferencesHandler() {
    }
    public void handlePreferences(AppEvent.PreferencesEvent e){
    }
}
