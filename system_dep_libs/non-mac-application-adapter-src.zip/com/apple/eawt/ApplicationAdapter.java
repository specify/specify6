//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.apple.eawt;

public class ApplicationAdapter {
    public ApplicationAdapter() {
    }
}
