To generate non-mac-application-adapter.jar stub lib:

in eawt/: javac *.java
in parent of com/: jar cf non-mac-application-adapter.jar com/apple/eawt/*.class

